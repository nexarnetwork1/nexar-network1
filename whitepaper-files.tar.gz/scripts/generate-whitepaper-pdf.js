const PDFDocument = require("pdfkit");
const fs = require("fs");

const INPUT = "./public/whitepaper.txt";
const OUTPUT = "./public/whitepaper.pdf";

const content = fs.readFileSync(INPUT, "utf8");

const doc = new PDFDocument({
  size: "A4",
  margins: {
    top: 60,
    bottom: 60,
    left: 60,
    right: 60,
  },
  info: {
    Title: "Nexar Network Whitepaper",
    Author: "Nexar Network",
    Subject: "Blockchain Payment Infrastructure",
    Creator: "Nexar Network",
  },
});

doc.pipe(fs.createWriteStream(OUTPUT));

const GOLD = "#D4AF37";
const DARK = "#202020";
const LIGHT = "#666666";

let page = 1;

function footer() {
  doc
    .fontSize(9)
    .fillColor("#999999")
    .text(
      `Page ${page}`,
      0,
      doc.page.height - 40,
      {
        align: "center",
      }
    );
}

function newPage() {
  footer();
  doc.addPage();
  page++;
}

function title(text) {
  if (doc.y > 650) newPage();

  doc
    .moveDown(0.8)
    .font("Helvetica-Bold")
    .fontSize(18)
    .fillColor(GOLD)
    .text(text);

  doc.moveDown(0.5);
}

function subtitle(text) {
  if (doc.y > 690) newPage();

  doc
    .font("Helvetica-Bold")
    .fontSize(14)
    .fillColor(DARK)
    .text(text);

  doc.moveDown(0.3);
}

function paragraph(text) {
  if (doc.y > 710) newPage();

  doc
    .font("Helvetica")
    .fontSize(11)
    .fillColor(DARK)
    .text(text, {
      width: 470,
      lineGap: 5,
      align: "justify",
    });

  doc.moveDown(0.4);
}

function bullet(text) {
  if (doc.y > 720) newPage();

  doc
    .font("Helvetica")
    .fontSize(11)
    .fillColor(DARK)
    .text("• " + text, {
      width: 470,
      indent: 15,
      lineGap: 4,
    });
}

function divider() {
  doc.moveDown(0.5);

  doc
    .strokeColor(GOLD)
    .lineWidth(1)
    .moveTo(60, doc.y)
    .lineTo(535, doc.y)
    .stroke();

  doc.moveDown(0.8);
}

// ------------------------------------------------------------------
// Cover Page
// ------------------------------------------------------------------

doc.rect(0, 0, doc.page.width, doc.page.height)
   .fill("#0A0A0A");

doc
  .fillColor(GOLD)
  .font("Helvetica-Bold")
  .fontSize(34)
  .text("NEXAR NETWORK", 0, 130, {
    align: "center",
  });

doc.moveDown();

doc
  .font("Helvetica")
  .fontSize(20)
  .fillColor("#FFFFFF")
  .text("WHITEPAPER", {
    align: "center",
  });


doc.moveDown(0.5);

doc
  .fontSize(13)
  .fillColor("#999999")
  .text("Building the Future of Global Payments", {
    align: "center",
  });

doc.moveDown();

doc
  .fontSize(11)
  .fillColor(GOLD)
  .text("High Speed • Low Fees • Secure • Scalable", {
    align: "center",
  });

doc.moveDown(14);

doc
  .fontSize(10)
  .fillColor("#777777")
  .text("© 2026 Nexar Network", {
    align: "center",
  });

newPage();


// ------------------------------------------------------------------
// Parse Whitepaper
// ------------------------------------------------------------------

const lines = content.split(/\r?\n/);

for (const rawLine of lines) {

  const line = rawLine.trim();

  if (!line) {
    doc.moveDown(0.5);
    continue;
  }

  // Ignore separators
  if (/^=+$/.test(line) || /^-+$/.test(line)) {
    divider();
    continue;
  }

  // Main Sections
  if (/^\d+\./.test(line)) {
    title(line);
    continue;
  }

  // PHASE
  if (/^PHASE/i.test(line)) {
    subtitle(line);
    continue;
  }

  // Bullet
  if (
    line.startsWith("•") ||
    line.startsWith("-")
  ) {
    bullet(line.replace(/^[-•]\s*/, ""));
    continue;
  }

  // Small headings
  if (
    line === line.toUpperCase() &&
    line.length < 35 &&
    !line.includes(".")
  ) {
    subtitle(line);
    continue;
  }

  paragraph(line);
}

// ------------------------------------------------------------------
// Final Footer
// ------------------------------------------------------------------

footer();

doc.end();

console.log("");
console.log("======================================");
console.log(" Nexar Whitepaper generated");
console.log(" File: ./public/whitepaper.pdf");
console.log("======================================");
console.log("");
